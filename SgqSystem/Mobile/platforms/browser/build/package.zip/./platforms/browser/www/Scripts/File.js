function createFile(){
    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fs) {

        console.log('file system open: ' + fs.name);
        fs.root.getFile("database.txt", { create: true, exclusive: false }, function (fileEntry) {
            console.log("fileEntry is file?" + fileEntry.isFile.toString());
            writeFile(fileEntry, new Blob([$('.Results').html()], { type: 'text/plain' }));
        }, onErrorCreateFile);

        fs.root.getFile("users.txt", { create: true, exclusive: false }, function (fileEntry) {
            var users = 
            '<div class="user" username="Antonio" userlogin="tony.colorado" userpass="123" userprofile="auditor">'+
            '<div class="user" username="Antonio" userlogin="jelsafa.colorado" userpass="123" userprofile="techinical">'+
            '<div class="user" username="Antonio" userlogin="lucas.colorado" userpass="123" userprofile="audit">';
            writeFile(fileEntry, new Blob([users], { type: 'text/plain' }));
            getUsers(fileEntry);
        }, onErrorCreateFile);


    }, onErrorLoadFs);
}


function writeFile(fileEntry, dataObj) {
    // Create a FileWriter object for our FileEntry (log.txt).
    fileEntry.createWriter(function (fileWriter) {

        fileWriter.onwriteend = function() {
            console.log("Result saved with success");
            //readFile(fileEntry);
        };

        fileWriter.onerror = function (e) {
            console.log("Failed file write: " + e.toString());
        };

        fileWriter.write(dataObj);
    });
}   


function readFile(fileEntry) {

    fileEntry.file(function (file) {
        var reader = new FileReader();

        reader.onloadend = function() {
            //console.log("Successful file read: " + this.result);
            //openMessageModal('leitura', 'Arquivo lido com sucesso.');
            if(this.result){
                $('.Results').empty();
                appendDevice(this.result, $('.Results'));
            }
        };

        reader.readAsText(file);

    }, onErrorReadFile);
}

function getUsers(fileEntry) {

    fileEntry.file(function (file) {
        var reader = new FileReader();

        reader.onloadend = function() {
            //console.log("Successful file read: " + this.result);
            //openMessageModal('leitura', 'Arquivo lido com sucesso.');
            if(this.result){
                $('.Users').lenght;
            }
        };

        reader.readAsText(file);

    }, onErrorReadFile);
}

function loginFile(){
    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fs) {
        fs.root.getFile("database.txt", { create: false, exclusive: false }, function (fileEntry) {
            readFile(fileEntry);
        }, onErrorCreateFile);
    }, onErrorLoadFs);
}

function onErrorLoadFs(e) {
    //openMessageModal( "FileSystem Error: "+e);
    console.log(e);
}

function onErrorCreateFile(e){
    //openMessageModal( "FileSystem Error: "+e);
    console.log(e);
}

function onErrorReadFile(e){
    //openMessageModal( "FileSystem Error: "+e);
    console.log(e);
}