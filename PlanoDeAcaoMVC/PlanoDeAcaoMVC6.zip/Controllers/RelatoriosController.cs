﻿using System.Web.Mvc;

namespace PlanoDeAcaoMVC.Controllers
{
    public class RelatoriosController : Controller
    {
        // GET: Relatorios
        public ActionResult Relatorios()
        {
            return View();
        }
    }
}