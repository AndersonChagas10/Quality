﻿using System.Web.Mvc;

namespace PlanoDeAcaoMVC.Controllers
{
    public class PaPlanejamentoAcaoController : Controller
    {
        // GET: PaPlanejamentoAcao
        public ActionResult Index()
        {
            return View();
        }

    }
}